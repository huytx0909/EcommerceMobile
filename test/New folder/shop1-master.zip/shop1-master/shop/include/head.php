<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <title>mobileshop</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet"  href="css/main.css">
<meta name "viewport" content="width=device-width, initial-scale=1,user-scalable=no">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>

</head>

<body>