<div id="content" class="space-top-none">
			
			<div class="space50">&nbsp;</div>
			<div class="row">
				<div class="col-md-8">
					<h2>Contact Form</h2>
					<div class="space20">&nbsp;</div>
					<h4>please input your name and email and send message. We will reply soon.</h4>
					<div class="space20">&nbsp;</div>
					<form action="#" method="post" class="contact-form">	
						<div id="form-group">
							      <span id="icon"><i id="fa fa-search"></i></span>

							<input name="your-name" class="form-control" type="text" placeholder="Your Name (required)">
						</div>
						<div id="form-group">
							      <span id="icon"><i id="fa fa-search"></i></span>

							<input name="your-email" type="email" class="form-control" placeholder="Your Email (required)">
						</div>
						
						<div id="form-group">
							      <span id="icon"><i id="fa fa-search"></i></span>

							<textarea name="your-message" class="form-control" placeholder="Your Message"></textarea>
						</div>
						<div id="form-block">
							<button type="submit" class="beta-btn primary">Send Message <i class="fa fa-chevron-right"></i></button>
						</div>
					</form>
				</div>
				<div class="col-md-4">
					<h2>Contact Information</h2>
					<div class="space20">&nbsp;</div>

					<h6 class="contact-title">Address</h6>
					<p>
						HaNoi university,<br>
						Nguyen Trai, Thanh Xuan <br>
						Ha Noi
					</p>
					
			</div>
		</div> <!-- #content -->
	</div> 